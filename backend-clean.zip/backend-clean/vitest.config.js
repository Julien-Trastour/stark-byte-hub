export default {
    test: {
      globals: true,
      environment: 'node',
      setupFiles: ['./tests/setup/globalSetup.test.js'],
    },
  }