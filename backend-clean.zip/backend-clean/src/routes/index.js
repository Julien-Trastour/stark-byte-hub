import v1 from './v1/index.js'
// import des futurs versions

export default {
  v1,
  // Export des versions
}